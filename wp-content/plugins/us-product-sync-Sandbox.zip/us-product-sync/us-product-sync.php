<?php
/**
 * Plugin Name:       US Product Sync
 * Description:       Inventory-only sync (quantity + stock status) from Universal Statues to WooCommerce.
 * Version:           1.0.2
 * Author:            Mosca Design
 * Text Domain:       us-product-sync
 * Requires at least: 6.2
 * Requires PHP:      8.0
 *
 * @package US_Product_Sync
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Main plugin class for US Product Sync.
 *
 * Handles API communication, product synchronization, and admin interface.
 *
 * @since 1.0.0
 */
class US_Product_Sync {

	/**
	 * Option key for sync schedule frequency.
	 */
	const OPT_SCHEDULE = 'usps_schedule';

	/**
	 * Option key for last sync timestamp.
	 */
	const OPT_LAST_SYNC = 'usps_last_sync';

	/**
	 * Option key for sync statistics.
	 */
	const OPT_SYNC_STATS = 'usps_sync_stats';

	/**
	 * Option key for product creation setting.
	 */
	const OPT_CREATE_NEW = 'usps_create_new_products';

	/**
	 * WP-Cron hook name.
	 */
	const CRON_HOOK = 'usps_cron_run';

	/**
	 * Transient key for preview data.
	 */
	const PREVIEW_KEY = 'usps_preview';

	/**
	 * Preview data cache duration in seconds.
	 */
	const PREVIEW_TTL = 900; // 15 minutes

	/**
	 * Prefix for log messages.
	 */
	const LOG_PREFIX = 'US_PRODUCT_SYNC';

	/**
	 * Maximum products to process in a single sync.
	 */
	const MAX_PRODUCTS = 10000;

	/**
	 * Number of products to process per batch.
	 */
	const BATCH_SIZE = 100;

	/**
	 * Number of batches between cache clears.
	 */
	const CACHE_CLEAR_FREQUENCY = 5;

	/**
	 * API request timeout in seconds.
	 */
	const API_TIMEOUT = 180;

	/**
	 * Singleton instance.
	 *
	 * @var US_Product_Sync|null
	 */
	private static $instance = null;

	/**
	 * Get singleton instance.
	 *
	 * @return US_Product_Sync
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Get API credentials from wp-config constants or environment variables.
	 *
	 * @return array{client_id: string, client_secret: string, endpoint: string}
	 */
	private function creds(): array {
		$client_id     = defined( 'MOSCA_US_CLIENT_ID' ) ? MOSCA_US_CLIENT_ID : getenv( 'MOSCA_US_CLIENT_ID' );
		$client_secret = defined( 'MOSCA_US_CLIENT_SECRET' ) ? MOSCA_US_CLIENT_SECRET : getenv( 'MOSCA_US_CLIENT_SECRET' );
		$endpoint      = defined( 'MOSCA_US_ENDPOINT_PRODUCTS' ) ? MOSCA_US_ENDPOINT_PRODUCTS : getenv( 'MOSCA_US_ENDPOINT_PRODUCTS' );

		return array(
			'client_id'     => is_string( $client_id ) ? trim( $client_id ) : '',
			'client_secret' => is_string( $client_secret ) ? trim( $client_secret ) : '',
			'endpoint'      => is_string( $endpoint ) ? trim( $endpoint ) : '',
		);
	}

	/**
	 * Constructor - sets up hooks and actions.
	 */
	private function __construct() {
		add_action( 'admin_menu', array( $this, 'register_settings_page' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), array( $this, 'row_action_link' ) );

		add_action( 'admin_post_usps_save', array( $this, 'handle_save' ) );
		add_action( 'admin_post_usps_preview', array( $this, 'handle_preview' ) );
		add_action( 'admin_post_usps_sync', array( $this, 'handle_sync' ) );
		add_action( 'admin_notices', array( $this, 'admin_notices' ) );

		add_action( self::CRON_HOOK, array( $this, 'cron_sync' ) );

		add_action( 'admin_init', array( $this, 'check_dependencies' ) );
	}

	/**
	 * Check for required dependencies (WooCommerce).
	 *
	 * @since 1.0.0
	 */
	public function check_dependencies() {
		if ( ! class_exists( 'WooCommerce' ) ) {
			add_action(
				'admin_notices',
				function () {
					echo '<div class="notice notice-error"><p>';
					echo esc_html__( 'US Product Sync requires WooCommerce to be installed and active.', 'us-product-sync' );
					echo '</p></div>';
				}
			);
			deactivate_plugins( plugin_basename( __FILE__ ) );
		}
	}

	/**
	 * Display admin notices.
	 *
	 * @since 1.0.0
	 */
	public function admin_notices() {
		if ( ! isset( $_GET['page'] ) || 'usps' !== $_GET['page'] ) {
			return;
		}

		if ( isset( $_GET['saved'] ) ) {
			echo '<div class="notice notice-success is-dismissible"><p>';
			echo esc_html__( 'Settings saved.', 'us-product-sync' );
			echo '</p></div>';
		}

		if ( isset( $_GET['synced'] ) ) {
			$stats = get_option( self::OPT_SYNC_STATS, array() );
			if ( ! empty( $stats ) ) {
				echo '<div class="notice notice-success is-dismissible"><p>';
				printf(
					/* translators: 1: updated count, 2: created count, 3: skipped count */
					esc_html__( 'Sync completed: %1$d products updated, %2$d created, %3$d skipped.', 'us-product-sync' ),
					$stats['updated'] ?? 0,
					$stats['created'] ?? 0,
					$stats['skipped'] ?? 0
				);
				echo '</p></div>';
			} else {
				echo '<div class="notice notice-success is-dismissible"><p>';
				echo esc_html__( 'Sync completed.', 'us-product-sync' );
				echo '</p></div>';
			}
		}

		if ( isset( $_GET['error'] ) ) {
			echo '<div class="notice notice-error is-dismissible"><p>';
			echo esc_html__( 'An error occurred. Please check the logs.', 'us-product-sync' );
			echo '</p></div>';
		}
	}

	/**
	 * Plugin activation hook.
	 *
	 * @since 1.0.0
	 */
	public static function activate() {
		if ( ! class_exists( 'WooCommerce' ) ) {
			wp_die( esc_html__( 'US Product Sync requires WooCommerce to be installed and active.', 'us-product-sync' ) );
		}

		if ( ! get_option( self::OPT_SCHEDULE ) ) {
			update_option( self::OPT_SCHEDULE, 'off' );
		}
		if ( ! get_option( self::OPT_CREATE_NEW ) ) {
			update_option( self::OPT_CREATE_NEW, 'yes' );
		}

		self::maybe_reschedule( get_option( self::OPT_SCHEDULE ) );
	}

	/**
	 * Plugin deactivation hook.
	 *
	 * @since 1.0.0
	 */
	public static function deactivate() {
		wp_clear_scheduled_hook( self::CRON_HOOK );
		delete_transient( self::PREVIEW_KEY );
	}

	/**
	 * Schedule or unschedule the WP-Cron event based on frequency setting.
	 *
	 * @since 1.0.0
	 * @param string $freq Frequency: 'off', 'daily', 'twicedaily', or 'weekly'.
	 */
	private static function maybe_reschedule( string $freq ) {
		wp_clear_scheduled_hook( self::CRON_HOOK );

		if ( 'off' === $freq ) {
			return;
		}

		// Validate frequency against WP-Cron schedules
		$schedules = wp_get_schedules();
		if ( ! isset( $schedules[ $freq ] ) ) {
			$freq = 'daily'; // Fallback to daily if invalid
		}

		// Calculate next run at 00:30 site local time
		$tz  = wp_timezone();
		$now = new DateTimeImmutable( 'now', $tz );

		$target_today = $now->setTime( 0, 30, 0 );
		$next         = ( $now < $target_today ) ? $target_today : $target_today->modify( '+1 day' );

		// Convert to UTC timestamp for wp_schedule_event
		$next_utc = $next->setTimezone( new DateTimeZone( 'UTC' ) )->getTimestamp();

		if ( ! wp_next_scheduled( self::CRON_HOOK ) ) {
			wp_schedule_event( $next_utc, $freq, self::CRON_HOOK );
		}
	}

	/**
	 * Add settings link to plugins page.
	 *
	 * @since 1.0.0
	 * @param array $links Existing action links.
	 * @return array Modified action links.
	 */
	public function row_action_link( $links ) {
		$url     = admin_url( 'options-general.php?page=usps' );
		$links[] = '<a href="' . esc_url( $url ) . '">' . esc_html__( 'Settings', 'us-product-sync' ) . '</a>';
		return $links;
	}

	/**
	 * Register settings page in admin menu.
	 *
	 * @since 1.0.0
	 */
	public function register_settings_page() {
		add_options_page(
			__( 'Universal Statues Product Sync', 'us-product-sync' ),
			__( 'US Product Sync', 'us-product-sync' ),
			'manage_options',
			'usps',
			array( $this, 'render_page' )
		);
	}

	/**
	 * Render settings page.
	 *
	 * @since 1.0.0
	 */
	public function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have sufficient permissions to access this page.', 'us-product-sync' ) );
		}

		$schedule   = get_option( self::OPT_SCHEDULE, 'off' );
		$create_new = get_option( self::OPT_CREATE_NEW, 'yes' );
		$last_sync  = get_option( self::OPT_LAST_SYNC );
		$preview    = get_transient( self::PREVIEW_KEY ) ?: array();
		$creds      = $this->creds();
		$creds_ok   = ( $creds['client_id'] && $creds['client_secret'] && $creds['endpoint'] );

		?>
		<div class="wrap">
			<h1><?php echo esc_html__( 'Universal Statues Product Sync', 'us-product-sync' ); ?></h1>

			<style>
				.card {
					max-width: 100%;
					box-sizing: border-box;
				}
				.usps-admin-wrap .form-table th {
					width: 200px;
				}
				.usps-preview-table {
					max-height: 600px;
					overflow-y: auto;
					border: 1px solid #c3c4c7;
					margin-bottom: 10px;
				}
				.usps-preview-table table {
					margin: 0;
					border: none;
				}
				.usps-preview-table thead th {
					position: sticky;
					top: 0;
					background: #f6f7f7;
					z-index: 10;
					border-top: none;
				}
			</style>

			<div class="usps-admin-wrap">

				<!-- Credentials Status -->
				<div class="card">
					<h2><?php echo esc_html__( 'API Credentials', 'us-product-sync' ); ?></h2>
					<table class="form-table">
						<tr>
							<th><?php echo esc_html__( 'Status', 'us-product-sync' ); ?></th>
							<td>
								<ul style="margin:0;">
									<li><?php echo esc_html__( 'Client ID:', 'us-product-sync' ); ?> <?php echo $creds['client_id'] ? '✅ ' . esc_html__( 'Configured', 'us-product-sync' ) : '❌ ' . esc_html__( 'Missing', 'us-product-sync' ); ?></li>
									<li><?php echo esc_html__( 'Client Secret:', 'us-product-sync' ); ?> <?php echo $creds['client_secret'] ? '✅ ' . esc_html__( 'Configured', 'us-product-sync' ) : '❌ ' . esc_html__( 'Missing', 'us-product-sync' ); ?></li>
									<li><?php echo esc_html__( 'Endpoint:', 'us-product-sync' ); ?> <?php echo $creds['endpoint'] ? '✅ ' . esc_html__( 'Configured', 'us-product-sync' ) : '❌ ' . esc_html__( 'Missing', 'us-product-sync' ); ?></li>
								</ul>
								<?php if ( ! $creds_ok ) : ?>
									<p class="description" style="color:#d63638;margin-top:10px;">
										<?php echo esc_html__( 'Define MOSCA_US_CLIENT_ID, MOSCA_US_CLIENT_SECRET, and MOSCA_US_ENDPOINT_PRODUCTS in wp-config.php or environment variables.', 'us-product-sync' ); ?>
									</p>
								<?php endif; ?>
							</td>
						</tr>
					</table>
				</div>

				<!-- Sync Settings -->
				<div class="card">
					<h2><?php echo esc_html__( 'Sync Settings', 'us-product-sync' ); ?></h2>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<?php wp_nonce_field( 'usps_save' ); ?>
						<input type="hidden" name="action" value="usps_save">
						<table class="form-table">
							<tr>
								<th scope="row">
									<label for="schedule"><?php echo esc_html__( 'Automatic Sync', 'us-product-sync' ); ?></label>
								</th>
								<td>
									<select name="schedule" id="schedule">
										<option value="off" <?php selected( $schedule, 'off' ); ?>><?php echo esc_html__( 'Off', 'us-product-sync' ); ?></option>
										<option value="daily" <?php selected( $schedule, 'daily' ); ?>><?php echo esc_html__( 'Daily', 'us-product-sync' ); ?></option>
										<option value="twicedaily" <?php selected( $schedule, 'twicedaily' ); ?>><?php echo esc_html__( 'Twice Daily', 'us-product-sync' ); ?></option>
										<option value="weekly" <?php selected( $schedule, 'weekly' ); ?>><?php echo esc_html__( 'Weekly', 'us-product-sync' ); ?></option>
									</select>
								</td>
							</tr>
							<tr>
								<th scope="row">
									<label for="create_new"><?php echo esc_html__( 'Product Creation', 'us-product-sync' ); ?></label>
								</th>
								<td>
									<fieldset>
										<label>
											<input type="radio" name="create_new" value="yes" <?php checked( $create_new, 'yes' ); ?>>
											<span><?php echo esc_html__( 'Create missing products as drafts', 'us-product-sync' ); ?></span>
										</label><br>
										<label>
											<input type="radio" name="create_new" value="no" <?php checked( $create_new, 'no' ); ?>>
											<span><?php echo esc_html__( 'Only update existing products', 'us-product-sync' ); ?></span>
										</label>
									</fieldset>
									<p class="description">
										<?php echo esc_html__( 'Choose whether to create new draft products for SKUs not found in WooCommerce, or only update inventory for existing products.', 'us-product-sync' ); ?>
									</p>
								</td>
							</tr>
						</table>
						<?php submit_button( __( 'Save Settings', 'us-product-sync' ) ); ?>
					</form>
				</div>

				<!-- Manual Actions -->
				<div class="card">
					<h2><?php echo esc_html__( 'Manual Actions', 'us-product-sync' ); ?></h2>
					<div style="display:flex;gap:10px;align-items:center;margin-bottom:15px;flex-wrap:wrap;">

						<form class="usps-action-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" data-action="preview">
							<?php wp_nonce_field( 'usps_preview' ); ?>
							<input type="hidden" name="action" value="usps_preview">
							<?php
							submit_button(
								__( 'Preview Data', 'us-product-sync' ),
								'secondary',
								'submit',
								false,
								$creds_ok ? array() : array( 'disabled' => 'disabled' )
							);
							?>
						</form>

						<form class="usps-action-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" data-action="sync">
							<?php wp_nonce_field( 'usps_sync' ); ?>
							<input type="hidden" name="action" value="usps_sync">
							<?php
							submit_button(
								__( 'Sync Now', 'us-product-sync' ),
								'primary',
								'submit',
								false,
								$creds_ok ? array() : array( 'disabled' => 'disabled' )
							);
							?>
						</form>

						<div id="usps-progress" style="display:none;align-items:center;gap:8px;">
							<span class="spinner is-active" style="float:none;margin:0;"></span>
						</div>
					</div>

					<!-- Preview Results -->
					<?php if ( ! empty( $preview['error'] ) ) : ?>
						<div class="notice notice-error inline">
							<p><?php echo esc_html__( 'Error:', 'us-product-sync' ) . ' ' . esc_html( $preview['error'] ); ?></p>
						</div>
					<?php elseif ( ! empty( $preview['items'] ) ) : ?>
						<h3><?php echo esc_html__( 'Data Preview (All Items)', 'us-product-sync' ); ?></h3>
						<p class="description">
							<?php
							printf(
								/* translators: %d: total count */
								esc_html__( 'Showing all %d items from API.', 'us-product-sync' ),
								count( $preview['items'] )
							);
							?>
						</p>
						<div class="usps-preview-table">
							<table class="widefat striped">
								<thead>
									<tr>
										<th style="width:5%;"><?php echo esc_html__( '#', 'us-product-sync' ); ?></th>
										<th style="width:15%;"><?php echo esc_html__( 'SKU', 'us-product-sync' ); ?></th>
										<th style="width:25%;"><?php echo esc_html__( 'Title', 'us-product-sync' ); ?></th>
										<th style="width:20%;"><?php echo esc_html__( 'In WooCommerce', 'us-product-sync' ); ?></th>
										<th style="width:15%;"><?php echo esc_html__( 'Quantity', 'us-product-sync' ); ?></th>
										<th style="width:20%;"><?php echo esc_html__( 'Last Updated', 'us-product-sync' ); ?></th>
									</tr>
								</thead>
								<tbody>
									<?php
									$create_new_setting = get_option( self::OPT_CREATE_NEW, 'yes' );
									$row_number = 0;
									foreach ( $preview['items'] as $item ) :
										$row_number++;
										$sku        = esc_html( $item['sku'] ?? '' );
										$product_id = $sku ? wc_get_product_id_by_sku( $sku ) : 0;
										$wc_product = $product_id ? wc_get_product( $product_id ) : null;
										$qty        = $item['quantity_for_sale'] ?? null;
										?>
										<tr>
											<td><?php echo $row_number; ?></td>
											<td>
												<code style="word-break:break-all;"><?php echo $sku; ?></code>
											</td>
											<td style="word-wrap:break-word;max-width:200px;">
												<?php echo esc_html( $item['title'] ?? '—' ); ?>
											</td>
											<td>
												<?php if ( $wc_product ) : ?>
													<span style="color:#00a32a;">✓ <?php echo esc_html__( 'Yes', 'us-product-sync' ); ?></span>
													<?php if ( 'draft' === $wc_product->get_status() ) : ?>
														<span style="color:#996800;">(<?php echo esc_html__( 'Draft', 'us-product-sync' ); ?>)</span>
													<?php endif; ?>
												<?php else : ?>
													<span style="color:#72777c;">
														<?php
														if ( 'yes' === $create_new_setting && $qty > 0 ) {
															echo '+ ' . esc_html__( 'Will Create', 'us-product-sync' );
														} else {
															echo '— ' . esc_html__( 'Skip', 'us-product-sync' );
														}
														?>
													</span>
												<?php endif; ?>
											</td>
											<td>
												<?php
												if ( null !== $qty ) {
													echo esc_html( $qty );
													if ( $wc_product && $wc_product->get_stock_quantity() != $qty ) {
														echo '<br><small style="color:#d63638;">(' . esc_html__( 'Now:', 'us-product-sync' ) . ' ' . esc_html( $wc_product->get_stock_quantity() ) . ')</small>';
													}
												} else {
													echo '—';
												}
												?>
											</td>
											<td>
												<?php
												$date = $item['updated_at'] ?? '';
												if ( $date && '—' !== $date ) {
													$timestamp = strtotime( $date );
													if ( $timestamp ) {
														echo esc_html( wp_date( 'M j, Y', $timestamp ) );
													} else {
														echo esc_html( $date );
													}
												} else {
													echo '—';
												}
												?>
											</td>
										</tr>
									<?php endforeach; ?>
								</tbody>
							</table>
						</div>
					<?php elseif ( isset( $preview['raw_snippet'] ) ) : ?>
						<h3><?php echo esc_html__( 'Raw API Response', 'us-product-sync' ); ?></h3>
						<pre style="max-height:300px;overflow:auto;background:#f6f7f7;padding:12px;border:1px solid #c3c4c7;border-radius:4px;word-wrap:break-word;white-space:pre-wrap;"><?php echo esc_html( $preview['raw_snippet'] ); ?></pre>
					<?php endif; ?>
				</div>
			</div>
		</div>

		<script>
		(function($){
			$('.usps-action-form').on('submit', function(){
				$('#usps-progress').css('display', 'inline-flex');
				$('.usps-action-form button, .usps-action-form input[type=submit]').prop('disabled', true);
			});
		})(jQuery);
		</script>
		<?php
	}

	/**
	 * Handle save settings POST request.
	 *
	 * @since 1.0.0
	 */
	public function handle_save() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have sufficient permissions.', 'us-product-sync' ) );
		}

		check_admin_referer( 'usps_save' );

		// Save schedule
		$schedule    = isset( $_POST['schedule'] ) ? sanitize_text_field( wp_unslash( $_POST['schedule'] ) ) : 'off';
		$valid_freqs = array( 'off', 'daily', 'twicedaily', 'weekly' );
		$schedule    = in_array( $schedule, $valid_freqs, true ) ? $schedule : 'off';
		update_option( self::OPT_SCHEDULE, $schedule );
		self::maybe_reschedule( $schedule );

		// Save product creation setting
		$create_new = isset( $_POST['create_new'] ) ? sanitize_text_field( wp_unslash( $_POST['create_new'] ) ) : 'no';
		$create_new = in_array( $create_new, array( 'yes', 'no' ), true ) ? $create_new : 'no';
		update_option( self::OPT_CREATE_NEW, $create_new );

		$this->log( 'Settings updated - Schedule: ' . $schedule . ', Create new: ' . $create_new );

		wp_safe_redirect( add_query_arg( array( 'page' => 'usps', 'saved' => '1' ), admin_url( 'options-general.php' ) ) );
		exit;
	}

	/**
	 * Handle preview POST request.
	 *
	 * @since 1.0.0
	 */
	public function handle_preview() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have sufficient permissions.', 'us-product-sync' ) );
		}

		check_admin_referer( 'usps_preview' );

		$preview = $this->fetch_preview();
		set_transient( self::PREVIEW_KEY, $preview, self::PREVIEW_TTL );

		$redirect_args = array( 'page' => 'usps' );
		if ( ! empty( $preview['error'] ) ) {
			$redirect_args['error'] = '1';
		}

		wp_safe_redirect( add_query_arg( $redirect_args, admin_url( 'options-general.php' ) ) );
		exit;
	}

	/**
	 * Handle manual sync POST request.
	 *
	 * @since 1.0.0
	 */
	public function handle_sync() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have sufficient permissions.', 'us-product-sync' ) );
		}

		check_admin_referer( 'usps_sync' );

		// Increase time limit for large syncs
		set_time_limit( 300 );

		$result = $this->sync_once();

		$redirect_args = array( 'page' => 'usps' );
		if ( false === $result ) {
			$redirect_args['error'] = '1';
		} else {
			$redirect_args['synced'] = '1';
		}

		wp_safe_redirect( add_query_arg( $redirect_args, admin_url( 'options-general.php' ) ) );
		exit;
	}

	/**
	 * WP-Cron callback for scheduled sync.
	 *
	 * @since 1.0.0
	 */
	public function cron_sync() {
		if ( ! wp_doing_cron() ) {
			$this->log( 'Attempted cron sync outside of WP-Cron context', 'warning' );
			return;
		}

		$this->log( 'Starting scheduled sync' );
		$this->sync_once();
	}

	/**
	 * Fetch preview data from API.
	 *
	 * @since 1.0.0
	 * @return array Preview data with items or error message.
	 */
	private function fetch_preview(): array {
		try {
			$res = $this->remote_get();
			if ( is_wp_error( $res ) ) {
				$this->log( 'Preview fetch error: ' . $res->get_error_message(), 'error' );
				return array( 'error' => $res->get_error_message() );
			}

			$code = (int) wp_remote_retrieve_response_code( $res );
			$body = (string) wp_remote_retrieve_body( $res );

			if ( $code < 200 || $code >= 300 ) {
				$this->log( 'Preview fetch HTTP error: ' . $code, 'error' );
				return array(
					'error'        => sprintf( __( 'HTTP Error %d', 'us-product-sync' ), $code ),
					'raw_snippet'  => $this->snippet( $body ),
				);
			}

			$j = json_decode( $body, true );
			if ( ! is_array( $j ) ) {
				return array(
					'error'       => __( 'Invalid JSON response', 'us-product-sync' ),
					'raw_snippet' => $this->snippet( $body ),
				);
			}

			if ( empty( $j['data'] ) || ! is_array( $j['data'] ) ) {
				return array(
					'error'       => __( 'No data found in response', 'us-product-sync' ),
					'raw_snippet' => $this->snippet( $body ),
				);
			}

			$items = array();
			foreach ( $j['data'] as $row ) {
				if ( ! is_array( $row ) ) {
					continue;
				}

				$items[] = array(
					'sku'               => isset( $row['number'] ) ? trim( (string) $row['number'] ) : '',
					'title'             => isset( $row['title'] ) ? trim( (string) $row['title'] ) : '',
					'quantity_for_sale' => isset( $row['quantity_for_sale'] ) ? $this->to_int( $row['quantity_for_sale'] ) : null,
					'updated_at'        => isset( $row['updated_at'] ) ? (string) $row['updated_at'] : '',
				);
			}

			$this->log( sprintf( 'Preview fetched %d items', count( $items ) ) );

			return array( 'items' => $items );

		} catch ( Exception $e ) {
			$this->log( 'Preview fetch exception: ' . $e->getMessage(), 'error' );
			return array( 'error' => $e->getMessage() );
		}
	}

	/**
	 * Execute a full sync operation.
	 *
	 * @since 1.0.0
	 * @return bool True on success, false on failure.
	 */
	private function sync_once() {
		$stats = array(
			'updated' => 0,
			'created' => 0,
			'skipped' => 0,
			'errors'  => 0,
			'total'   => 0,
		);

		try {
			$res = $this->remote_get();
			if ( is_wp_error( $res ) ) {
				$this->log( 'Sync error: ' . $res->get_error_message(), 'error' );
				return false;
			}

			$code = (int) wp_remote_retrieve_response_code( $res );
			$body = (string) wp_remote_retrieve_body( $res );

			if ( $code < 200 || $code >= 300 ) {
				$this->log( 'Sync HTTP error: ' . $code, 'error' );
				return false;
			}

			$j = json_decode( $body, true );
			if ( ! is_array( $j ) || empty( $j['data'] ) ) {
				$this->log( 'Invalid or empty response data', 'error' );
				return false;
			}

			$total_items = count( $j['data'] );
			if ( $total_items > self::MAX_PRODUCTS ) {
				$this->log( sprintf( 'Too many products (%d), limiting to %d', $total_items, self::MAX_PRODUCTS ), 'warning' );
				$j['data'] = array_slice( $j['data'], 0, self::MAX_PRODUCTS );
			}

			$stats['total'] = count( $j['data'] );

			// Process in batches to avoid memory issues
			$batches = array_chunk( $j['data'], self::BATCH_SIZE );

			foreach ( $batches as $batch_num => $batch ) {
				foreach ( $batch as $row ) {
					if ( ! is_array( $row ) ) {
						$stats['skipped']++;
						continue;
					}

					$result = $this->create_or_update_inventory( $row );
					if ( 'created' === $result ) {
						$stats['created']++;
					} elseif ( 'updated' === $result ) {
						$stats['updated']++;
					} elseif ( 'skipped' === $result ) {
						$stats['skipped']++;
					} else {
						$stats['errors']++;
					}
				}

				// Clear caches periodically
				if ( 0 === $batch_num % self::CACHE_CLEAR_FREQUENCY ) {
					wc_delete_product_transients();
				}
			}

			// Update sync metadata
			update_option( self::OPT_LAST_SYNC, time() );
			update_option( self::OPT_SYNC_STATS, $stats );

			$this->log(
				sprintf(
					'Sync completed: %d total, %d updated, %d created, %d skipped, %d errors',
					$stats['total'],
					$stats['updated'],
					$stats['created'],
					$stats['skipped'],
					$stats['errors']
				)
			);

			// Clear WooCommerce caches
			wc_delete_product_transients();

			return true;

		} catch ( Exception $e ) {
			$this->log( 'Sync exception: ' . $e->getMessage(), 'error' );
			return false;
		}
	}

	/**
	 * Make API request to Universal Statues endpoint.
	 *
	 * @since 1.0.0
	 * @return array|WP_Error Response array or WP_Error on failure.
	 */
	private function remote_get() {
		$c = $this->creds();
		if ( ! $c['client_id'] || ! $c['client_secret'] || ! $c['endpoint'] ) {
			return new WP_Error( 'usps_creds', __( 'Missing API credentials or endpoint.', 'us-product-sync' ) );
		}

		// Validate endpoint URL
		if ( ! filter_var( $c['endpoint'], FILTER_VALIDATE_URL ) ) {
			return new WP_Error( 'usps_invalid_url', __( 'Invalid endpoint URL.', 'us-product-sync' ) );
		}

		$args = array(
			'headers'     => array(
				'client_id'     => $c['client_id'],
				'client_secret' => $c['client_secret'],
				'Accept'        => 'application/json',
				'User-Agent'    => 'US-Product-Sync/1.0.2 WordPress/' . get_bloginfo( 'version' ),
			),
			'timeout'     => self::API_TIMEOUT,
			'httpversion' => '1.1',
			'sslverify'   => true,
		);

		return wp_remote_get( $c['endpoint'], $args );
	}

	/**
	 * Create or update product inventory based on API data.
	 *
	 * @since 1.0.0
	 * @param array $r Product data from API.
	 * @return string Status: 'created', 'updated', 'skipped', or 'error'.
	 */
	private function create_or_update_inventory( array $r ): string {
		try {
			$sku = isset( $r['number'] ) ? trim( (string) $r['number'] ) : '';
			if ( '' === $sku ) {
				return 'skipped';
			}

			$qty        = isset( $r['quantity_for_sale'] ) ? $this->to_int( $r['quantity_for_sale'] ) : null;
			$updated_at = isset( $r['updated_at'] ) ? (string) $r['updated_at'] : '';
			$title      = isset( $r['title'] ) ? trim( (string) $r['title'] ) : '';

			$product_id = wc_get_product_id_by_sku( $sku );

			if ( $product_id ) {
				// Update existing product
				$product = wc_get_product( $product_id );
				if ( ! $product ) {
					$this->log( 'Product not found for ID: ' . $product_id, 'warning' );
					return 'error';
				}

				$current_qty         = $product->get_stock_quantity();
				$current_stock_mgmt  = $product->get_manage_stock();
				$current_status      = $product->get_stock_status();
				$needs_update        = false;

				// Check if quantity or stock management has changed
				if ( null !== $qty ) {
					$new_status = $qty > 0 ? 'instock' : 'outofstock';
					
					// Update if: quantity changed, stock management disabled, or status doesn't match
					if ( $current_qty != $qty || ! $current_stock_mgmt || $current_status !== $new_status ) {
						$product->set_manage_stock( true );
						$product->set_stock_quantity( $qty );
						$product->set_stock_status( $new_status );
						$needs_update = true;
					}
				}

				if ( $needs_update ) {
					$product->save();

					if ( $updated_at ) {
						update_post_meta( $product_id, '_us_sync_updated_at', $updated_at );
					}
					update_post_meta( $product_id, '_us_last_sync', current_time( 'mysql' ) );

					$this->log( sprintf( 'Updated SKU %s: qty %s -> %d, status: %s', $sku, $current_qty ?? 'null', $qty, $new_status ) );
					return 'updated';
				}

				// Still update the sync timestamp even if qty unchanged
				update_post_meta( $product_id, '_us_last_sync', current_time( 'mysql' ) );
				return 'skipped';
			}

			// Check if we should create new products
			$create_new = get_option( self::OPT_CREATE_NEW, 'yes' );
			if ( 'yes' !== $create_new ) {
				$this->log( sprintf( 'Skipping creation for SKU %s (create new products disabled)', $sku ) );
				return 'skipped';
			}

			// Only create if qty > 0
			if ( null === $qty || $qty <= 0 ) {
				return 'skipped';
			}

			// Create minimal product in draft status
			$product = new WC_Product_Simple();
			$product->set_status( 'draft' );
			$product->set_catalog_visibility( 'hidden' );
			$product->set_manage_stock( true );
			$product->set_stock_quantity( $qty );
			$product->set_stock_status( 'instock' );
			$product->set_sku( $sku );
			$product->set_name( '' !== $title ? $title : $sku );

			// Set meta flags to identify products created by this plugin
			$product->add_meta_data( '_created_by_us_sync', 'yes', true );
			$product->add_meta_data( '_us_sync_updated_at', $updated_at, true );
			$product->add_meta_data( '_us_last_sync', current_time( 'mysql' ), true );

			$new_id = $product->save();

			if ( $new_id ) {
				$this->log( sprintf( 'Created new product for SKU %s with qty %d', $sku, $qty ) );
				return 'created';
			} else {
				$this->log( 'Failed to create product for SKU: ' . $sku, 'error' );
				return 'error';
			}

		} catch ( Exception $e ) {
			$this->log( 'Error processing SKU ' . ( $sku ?? 'unknown' ) . ': ' . $e->getMessage(), 'error' );
			return 'error';
		}
	}

	/**
	 * Convert value to integer, handling various input formats.
	 *
	 * @since 1.0.0
	 * @param mixed $v Value to convert.
	 * @return int|null Integer value or null if invalid.
	 */
	private function to_int( $v ) {
		if ( null === $v || '' === $v ) {
			return null;
		}
		if ( is_numeric( $v ) ) {
			return (int) $v;
		}
		// Clean string values
		$cleaned = preg_replace( '/[^0-9-]/', '', (string) $v );
		if ( '' === $cleaned || '-' === $cleaned ) {
			return null;
		}
		return (int) $cleaned;
	}

	/**
	 * Truncate string to specified length with ellipsis.
	 *
	 * @since 1.0.0
	 * @param string $s   String to truncate.
	 * @param int    $len Maximum length.
	 * @return string Truncated string.
	 */
	private function snippet( string $s, int $len = 800 ): string {
		return mb_strlen( $s ) <= $len ? $s : mb_substr( $s, 0, $len - 3 ) . '...';
	}

	/**
	 * Log messages for debugging.
	 *
	 * @since 1.0.0
	 * @param string $message Message to log.
	 * @param string $level   Log level: 'info', 'warning', or 'error'.
	 */
	private function log( string $message, string $level = 'info' ) {
		if ( ! defined( 'WP_DEBUG' ) || ! WP_DEBUG ) {
			return;
		}

		$log_message = sprintf(
			'[%s] %s: %s',
			current_time( 'Y-m-d H:i:s' ),
			self::LOG_PREFIX,
			$message
		);

		error_log( $log_message );

		// Also log to WooCommerce logs if available
		if ( function_exists( 'wc_get_logger' ) ) {
			$logger  = wc_get_logger();
			$context = array( 'source' => 'us-product-sync' );

			switch ( $level ) {
				case 'error':
					$logger->error( $message, $context );
					break;
				case 'warning':
					$logger->warning( $message, $context );
					break;
				default:
					$logger->info( $message, $context );
					break;
			}
		}
	}
}

/**
 * Initialize the plugin.
 */
add_action(
	'plugins_loaded',
	function () {
		US_Product_Sync::get_instance();
	}
);

/**
 * Plugin uninstall handler.
 *
 * @since 1.0.0
 */
function us_product_sync_uninstall() {
	// Clean up options
	delete_option( 'usps_schedule' );
	delete_option( 'usps_last_sync' );
	delete_option( 'usps_sync_stats' );
	delete_option( 'usps_create_new_products' );
	delete_transient( 'usps_preview' );

	// Clear scheduled events
	wp_clear_scheduled_hook( 'usps_cron_run' );
}

register_uninstall_hook( __FILE__, 'us_product_sync_uninstall' );
register_activation_hook( __FILE__, array( 'US_Product_Sync', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'US_Product_Sync', 'deactivate' ) );